package AuthorNoPod;

use strict;
use warnings;

use lib 't/lib';
use base 'SimpleBaseClass';

## Does nothing here, should inherit "mymethod" from "SimpleBaseClass"

1;

=pod

=head1 AUTHOR

James Mastros <james@mastros.biz>

=head1 LICENSE

As Perl itself.
Hopefully the inherited pod goes before author

=cut
