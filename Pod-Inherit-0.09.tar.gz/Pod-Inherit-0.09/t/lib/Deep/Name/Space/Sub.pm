package Deep::Name::Space::Sub;
use warnings;
use strict;
use base 'Deep::Name::Space::Base';

'this is here to check if deeply namespaced names work correctly';
