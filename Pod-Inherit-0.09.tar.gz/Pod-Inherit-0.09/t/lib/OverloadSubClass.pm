package OverloadSubClass;
use warnings;
use strict;
use base 'OverloadBaseClass';

sub local_method {
  'Your mother';
}

1;
