package OverrideDoubleSubClass;
use warnings;
use strict;
use base 'OverrideSubClass';

# The method should come from OverrideSubClass, *not* from OverrideBaseClass.

1;
