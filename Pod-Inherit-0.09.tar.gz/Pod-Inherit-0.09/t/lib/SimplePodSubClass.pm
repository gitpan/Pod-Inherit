package SimplePodSubClass;

use strict;
use warnings;

use lib 't/lib';
use base 'SimpleBaseClass';

## Does nothing here, should inherit "mymethod" from "SimpleBaseClass"

1;

=pod

=head1 NAME

SimplePodSubClass - Already with POD

=head1 SYNOPSIS

UUHUHJIIOJ

=cut
