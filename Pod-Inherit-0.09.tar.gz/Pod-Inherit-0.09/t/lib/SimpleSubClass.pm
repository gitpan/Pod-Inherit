package SimpleSubClass;

use strict;
use warnings;

use lib 't/lib';
use base 'SimpleBaseClass';

## Does nothing here, should inherit "mymethod" from "SimpleBaseClass"

1;
