package SkipUnderscoreBaseClass;
use warnings;
use strict;

sub _hide_this {
  'here there be dragons';
}

sub show_this {
  'here there be chickens';
}

'spam and spam sandwich';

