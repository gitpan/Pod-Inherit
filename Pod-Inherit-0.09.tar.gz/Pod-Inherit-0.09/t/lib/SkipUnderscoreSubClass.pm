package SkipUnderscoreSubClass;
use warnings;
use strict;
use base 'SkipUnderscoreBaseClass';

sub in_sub_class {
  'here I am';
}

1;
