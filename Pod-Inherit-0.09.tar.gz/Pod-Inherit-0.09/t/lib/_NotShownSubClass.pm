package _NotShownSubClass;
use warnings;
use strict;
use base '_NotShownBaseClass';

sub in_sub_class {
  'here I am';
}

1;
