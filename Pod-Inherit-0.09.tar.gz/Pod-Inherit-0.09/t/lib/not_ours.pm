package not_ours;
use warnings;
use strict;
"It doesn't matter what is in here, so long as it's valid perl";
