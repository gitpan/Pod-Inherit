package ClassC3Base;

use strict;
use warnings;

use Class::C3;

sub myc3method {
  'nutting here';
}

1;

=head1 NAME

ClassC3Base - Class::C3 base test

