package ClassC3Sub;

use strict;
use warnings;

use base 'ClassC3Base';
use Class::C3;

1;
