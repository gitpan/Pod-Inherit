package MooseSub;

use strict;
use warnings;

use Moose;
extends 'MooseBase';

no Moose;

__PACKAGE__->meta->make_immutable;

1;


=head1 NAME

MooseSub - Sub Moose class

=head1 SYNOPSIS

Blah

=head1 DESCRIPTION

Blah

=head1 AUTHOR

James Mastros <james@mastros.biz>

=head1 LICENSE

Stuff

