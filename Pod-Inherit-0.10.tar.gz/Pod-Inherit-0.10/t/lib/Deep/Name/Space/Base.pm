package Deep::Name::Space::Base;
use warnings;
use strict;

sub from_base {
  'I demand that I may or may not be Voorfindle';
}

'this file is here to be a base class for Deep::Name::Space::Sub';
