package InlineSubConfig;

use strict;
use warnings;

use base 'InlineBaseConfig';

1;
