package NoPodBaseClass;

use strict;
use warnings;

sub mymethod {
    my ($class, $input) = @_;

    ## Does nothing

}

1;
