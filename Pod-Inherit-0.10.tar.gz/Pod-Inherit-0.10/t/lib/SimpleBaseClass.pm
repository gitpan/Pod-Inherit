package SimpleBaseClass;

use strict;
use warnings;

sub mymethod {
    my ($class, $input) = @_;

    ## Does nothing

}

1;

=head1 NAME

SimpleBaseClass - A base class with one method (and some POD)

